<head>
    <meta charset="utf-8" />
    <title>Uzuri Institute | <?php echo $title?></title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />  
    <meta name="description" content="Website Description" />
    <meta name="keywords" content="Website Keywords" />
    <link rel="stylesheet" type="text/css" media="all" href="<?php echo site_url();?>assets/themes/braink/style/style.css" />
    <link rel="stylesheet" type="text/css" media="all" href="<?php echo site_url();?>assets/themes/braink/style/prettyPhoto.css" />
    <link href='http://fonts.googleapis.com/css?family=Raleway:400,700,300,900' rel='stylesheet' type='text/css' />
    <link href='http://fonts.googleapis.com/css?family=Nunito:400,300,700' rel='stylesheet' type='text/css' />
    <link rel="stylesheet" type="text/css" media="all" href="<?php echo site_url();?>assets/themes/braink/style/stylemobile.css" />
    <!-- <link rel="stylesheet" type="text/css" media="all" href="style/mobilenavigation.css" /> -->
    <script src="<?php echo site_url();?>assets/themes/braink/script/modernizr.js" type="text/javascript"></script>
    <script src="<?php echo site_url();?>assets/themes/braink/script/jquery.js" type="text/javascript"></script>
</head>
